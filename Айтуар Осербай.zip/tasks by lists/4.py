some = []
n = int(input("введите переменную N :"))
for i in range(n):
	inp = input("введите переменную :")
	some.append(inp)
print(some)
