lis = [1, 34, 8, 0, -5, 7, 32, 74, 59, 92, 41, 10,-2]
print("минимальное число в списке :",min(lis))

lis.append(-5)
lis.remove(-5)
print(lis)