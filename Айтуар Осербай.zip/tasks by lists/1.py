lis = ["Андрей", "Иван", "Василий", "Петро", "Максим", "Дима"]
print(lis[0])
for i in lis[0]:
	print(i)
print(lis[1])
for i in lis[1]:
	print(i)
print(lis[2])
for i in lis[2]:
	print(i)
print(lis[3])
for i in lis[3]:
	print(i)
print(lis[4])
for i in lis[4]:
	print(i)
print(lis[5])
for i in lis[5]:
	print(i)